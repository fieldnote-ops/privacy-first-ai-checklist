# 15-minute client workflow handoff preflight — preview

Use a fictional or fully redacted workflow. Never paste client names, URLs, account IDs, credentials, tokens, production data, contract details, or screenshots.

## Synthetic example

An automation freelancer built an invoice-intake workflow. It reads a client-owned mailbox, extracts fields with an LLM, writes approved rows to a spreadsheet, and alerts an operator when confidence is low. The example is fictional.

## Timer

- Start: `HH:MM`
- Finish: `HH:MM`
- If unfinished after 15 minutes, stop and mark the first field that blocked you.

## 1. Ownership

| Item | Owner at handoff | Recovery owner | Evidence location |
|---|---|---|---|
| Automation instance and billing |  |  |  |
| Source/export and version history |  |  |  |
| Data store and backups |  |  |  |

## 2. Credentials — names and owners only

Do not record secret values.

| Connection purpose | Account owner | Grant method | Revoke/rotate owner | Builder access ends |
|---|---|---|---|---|
| Read inbound mailbox |  | OAuth / service account / other |  |  |
| Write approved records |  | OAuth / service account / other |  |  |
| Call model provider |  | client key / client billing / other |  |  |

## 3. Action boundary

| Action type | Default | Human approver | What the approver must see | Approval expires |
|---|---|---|---|---|
| Read within agreed mailbox/filter | allow / approve / deny |  |  |  |
| Write a new draft row | allow / approve / deny |  |  |  |
| Modify/delete an existing record | allow / approve / deny |  |  |  |
| Send externally or change access | allow / approve / deny |  |  |  |

An approval must refer to the actual action and relevant parameters—not only an AI-written summary.

## 4. Verification and rollback

- Last verified version/date:
- One synthetic failure test that must pass:
- Kill/disable method and owner:
- Restore or compensation step:
- Expected data left after a failed run:

## 5. Offboarding receipt

At engagement end, can both sides record:

- [ ] Client can run, pause and recover without the builder.
- [ ] Client owns billing, instance, source/export and required connections.
- [ ] Builder access, tokens and shared accounts are removed or time-limited.
- [ ] Current version, dependencies, known limitations and last test date are recorded.
- [ ] Approval and rollback owners accepted their roles.

## Result

- First missing or ambiguous fact:
- Would this omission have caused extra calls, rework, support, access risk, or no consequence?
- Which single section would you keep in a real client handoff?

This preview is an operational prompt, not a security certification, contract, legal opinion, or platform configuration tool.
